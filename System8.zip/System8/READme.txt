*In order for this .EXE file to work, it required the boot.bin file in the same directory*
					'SorcererGG'